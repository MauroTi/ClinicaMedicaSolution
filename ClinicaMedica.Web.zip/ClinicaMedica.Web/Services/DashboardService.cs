﻿using ClinicaMedica.Web.Daos.Interfaces;
using ClinicaMedica.Web.ViewModels.Dashboard;

namespace ClinicaMedica.Web.Services
{
    public class DashboardService
    {
        private readonly IDashboardDao _dashboardDao;

        public DashboardService(IDashboardDao dashboardDao)
        {
            _dashboardDao = dashboardDao;
        }

        public DashboardViewModel ObterDadosDashboard()
        {
            return _dashboardDao.ObterDadosDashboard();
        }
    }
}