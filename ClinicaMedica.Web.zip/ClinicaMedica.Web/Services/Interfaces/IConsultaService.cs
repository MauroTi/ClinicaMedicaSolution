﻿using ClinicaMedica.Web.Models;

namespace ClinicaMedica.Web.Services.Interfaces
{
    public interface IConsultaService
    {
        Task<IEnumerable<Consulta>> ObterTodasAsync();
        Task<Consulta?> ObterPorIdAsync(int id);
        Task<int> AdicionarAsync(Consulta consulta);
        Task<bool> AtualizarAsync(Consulta consulta);
        Task<bool> ExcluirAsync(int id);
    }
}