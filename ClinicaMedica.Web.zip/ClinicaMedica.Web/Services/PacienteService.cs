﻿using ClinicaMedica.Web.Daos.Interfaces;
using ClinicaMedica.Web.Models;

namespace ClinicaMedica.Web.Services
{
    public class PacienteService
    {
        private readonly IPacienteDao _pacienteDao;

        public PacienteService(IPacienteDao pacienteDao)
        {
            _pacienteDao = pacienteDao;
        }

        public IEnumerable<Paciente> ObterTodos()
        {
            return _pacienteDao.ObterTodos();
        }

        public Paciente? ObterPorId(int id)
        {
            return _pacienteDao.ObterPorId(id);
        }
    }
}