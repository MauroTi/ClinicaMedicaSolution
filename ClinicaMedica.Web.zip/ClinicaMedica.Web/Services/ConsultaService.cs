﻿using ClinicaMedica.Web.Daos.Interfaces;
using ClinicaMedica.Web.Models;

namespace ClinicaMedica.Web.Services
{
    public class ConsultaService
    {
        private readonly IConsultaDao _consultaDao;

        public ConsultaService(IConsultaDao consultaDao)
        {
            _consultaDao = consultaDao;
        }

        public IEnumerable<Consulta> ObterTodos()
        {
            return _consultaDao.ObterTodos();
        }

        public Consulta? ObterPorId(int id)
        {
            return _consultaDao.ObterPorId(id);
        }
    }
}