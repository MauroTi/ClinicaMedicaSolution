﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using ClinicaMedica.Web.Models;
using ClinicaMedica.Web.Services.Interfaces;
using ClinicaMedica.Web.ViewModels.Consultas;
using ClinicaMedica.Web.Helpers;

namespace ClinicaMedica.Web.Controllers
{
    public class ConsultasController : Controller
    {
        private readonly ConsultaService _consultaService;
        private readonly MedicoService _medicoService;
        private readonly PacienteService _pacienteService;

        public ConsultasController(
            ConsultaService consultaService,
            MedicoService medicoService,
            PacienteService pacienteService)
        {
            _consultaService = consultaService;
            _medicoService = medicoService;
            _pacienteService = pacienteService;
        }

        public IActionResult Index()
        {
            var consultas = _consultaService.ObterTodos();
            var medicos = _medicoService.ObterTodos().ToDictionary(m => m.Id, m => m.Nome);
            var pacientes = _pacienteService.ObterTodos().ToDictionary(p => p.Id, p => p.Nome);

            var viewModel = new ConsultaIndexViewModel
            {
                Consultas = consultas.Select(c => new ConsultaListItemViewModel
                {
                    Id = c.Id,
                    MedicoId = c.MedicoId,
                    MedicoNome = medicos.ContainsKey(c.MedicoId) ? medicos[c.MedicoId] : "N/A",
                    PacienteId = c.PacienteId,
                    PacienteNome = pacientes.ContainsKey(c.PacienteId) ? pacientes[c.PacienteId] : "N/A",
                    DataHoraConsulta = c.DataHoraConsulta,
                    Valor = c.Valor,
                    Status = c.Status,
                    Observacoes = c.Observacoes,
                    DataCadastro = c.DataCadastro
                }).ToList()
            };

            return View(viewModel);
        }

        public IActionResult Details(int id)
        {
            var consulta = _consultaService.ObterPorId(id);

            if (consulta == null)
                return NotFound();

            var viewModel = ConsultaFormViewModel.FromModel(consulta);
            viewModel.ModoSomenteLeitura = true;

            CarregarCombos(viewModel);

            return View(viewModel);
        }

        public IActionResult Create()
        {
            var viewModel = new ConsultaFormViewModel
            {
                DataHoraConsulta = DateTime.Now,
                DataCadastro = DateTime.Now,
                Status = "Agendada"
            };

            CarregarCombos(viewModel);

            return View(viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(ConsultaFormViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                CarregarCombos(viewModel);
                return View(viewModel);
            }

            // TODO: Implementar salvar quando CRUD completo estiver pronto
            TempData["Sucesso"] = "Cadastro de consulta pronto para integração com persistência.";
            return RedirectToAction(nameof(Index));
        }

        public IActionResult Edit(int id)
        {
            var consulta = _consultaService.ObterPorId(id);

            if (consulta == null)
                return NotFound();

            var viewModel = ConsultaFormViewModel.FromModel(consulta);

            CarregarCombos(viewModel);

            return View(viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(ConsultaFormViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                CarregarCombos(viewModel);
                return View(viewModel);
            }

            // TODO: Implementar atualização quando CRUD completo estiver pronto
            TempData["Sucesso"] = "Edição de consulta pronta para integração com persistência.";
            return RedirectToAction(nameof(Index));
        }

        public IActionResult Delete(int id)
        {
            var consulta = _consultaService.ObterPorId(id);

            if (consulta == null)
                return NotFound();

            var viewModel = ConsultaFormViewModel.FromModel(consulta);
            viewModel.ModoSomenteLeitura = true;

            CarregarCombos(viewModel);

            return View(viewModel);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            // TODO: Implementar exclusão quando CRUD completo estiver pronto
            TempData["Sucesso"] = "Exclusão de consulta pronta para integração com persistência.";
            return RedirectToAction(nameof(Index));
        }

        private void CarregarCombos(ConsultaFormViewModel viewModel)
        {
            viewModel.Medicos = _medicoService.ObterTodos()
                .Select(m => new SelectListItem
                {
                    Value = m.Id.ToString(),
                    Text = $"{m.Nome} - {m.Especialidade}"
                })
                .ToList();

            viewModel.Pacientes = _pacienteService.ObterTodos()
                .Select(p => new SelectListItem
                {
                    Value = p.Id.ToString(),
                    Text = p.Nome
                })
                .ToList();

            viewModel.StatusDisponiveis = new List<SelectListItem>
            {
                new SelectListItem { Value = "Agendada", Text = "Agendada" },
                new SelectListItem { Value = "Confirmada", Text = "Confirmada" },
                new SelectListItem { Value = "Realizada", Text = "Realizada" },
                new SelectListItem { Value = "Cancelada", Text = "Cancelada" }
            };
        }
    }
}