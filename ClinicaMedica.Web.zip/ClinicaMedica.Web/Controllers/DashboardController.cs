﻿using ClinicaMedica.Web.Services;
using Microsoft.AspNetCore.Mvc;

namespace ClinicaMedica.Web.Controllers
{
    public class DashboardController : Controller
    {
        private readonly DashboardService _dashboardService;

        public DashboardController(DashboardService dashboardService)
        {
            _dashboardService = dashboardService;
        }

        public IActionResult Index()
        {
            var viewModel = _dashboardService.ObterDadosDashboard();
            return View(viewModel);
        }
    }
}