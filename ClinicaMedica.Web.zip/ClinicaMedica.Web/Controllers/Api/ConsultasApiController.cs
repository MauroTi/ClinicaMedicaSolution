﻿using ClinicaMedica.Web.Models;
using ClinicaMedica.Web.Services;
using Microsoft.AspNetCore.Mvc;

namespace ClinicaMedica.Web.Controllers.Api
{
    [ApiController]
    [Route("api/[controller]")]
    public class ConsultasApiController : ControllerBase
    {
        private readonly IConsultaService _consultaService;

        public ConsultasApiController(IConsultaService consultaService)
        {
            _consultaService = consultaService;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var consultas = await _consultaService.ObterTodosDetalhadosAsync();
            return Ok(consultas);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var consulta = await _consultaService.ObterDtoPorIdAsync(id);
            if (consulta == null) return NotFound();

            return Ok(consulta);
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] Consulta model)
        {
            var resultado = await _consultaService.CriarAsync(model);

            if (!resultado.Sucesso)
                return BadRequest(new { resultado.Mensagem });

            return CreatedAtAction(nameof(Get), new { id = resultado.Id }, model);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int id, [FromBody] Consulta model)
        {
            if (id != model.Id)
                return BadRequest(new { Mensagem = "ID da rota difere do ID do corpo." });

            var resultado = await _consultaService.AtualizarAsync(model);

            if (!resultado.Sucesso)
                return BadRequest(new { resultado.Mensagem });

            return Ok(new { resultado.Mensagem });
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var resultado = await _consultaService.ExcluirAsync(id);

            if (!resultado.Sucesso)
                return BadRequest(new { resultado.Mensagem });

            return Ok(new { resultado.Mensagem });
        }
    }
}