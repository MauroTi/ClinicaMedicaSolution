﻿using ClinicaMedica.Web.Models;
using ClinicaMedica.Web.Services;
using Microsoft.AspNetCore.Mvc;

namespace ClinicaMedica.Web.Controllers.Api
{
    [ApiController]
    [Route("api/[controller]")]
    public class MedicosApiController : ControllerBase
    {
        private readonly IMedicoService _medicoService;

        public MedicosApiController(IMedicoService medicoService)
        {
            _medicoService = medicoService;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var medicos = await _medicoService.ObterTodosAsync();
            return Ok(medicos);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var medico = await _medicoService.ObterDtoPorIdAsync(id);
            if (medico == null) return NotFound();

            return Ok(medico);
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] Medico model)
        {
            var resultado = await _medicoService.CriarAsync(model);

            if (!resultado.Sucesso)
                return BadRequest(new { resultado.Mensagem });

            return CreatedAtAction(nameof(Get), new { id = resultado.Id }, model);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int id, [FromBody] Medico model)
        {
            if (id != model.Id)
                return BadRequest(new { Mensagem = "ID da rota difere do ID do corpo." });

            var resultado = await _medicoService.AtualizarAsync(model);

            if (!resultado.Sucesso)
                return BadRequest(new { resultado.Mensagem });

            return Ok(new { resultado.Mensagem });
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var resultado = await _medicoService.ExcluirAsync(id);

            if (!resultado.Sucesso)
                return BadRequest(new { resultado.Mensagem });

            return Ok(new { resultado.Mensagem });
        }
    }
}