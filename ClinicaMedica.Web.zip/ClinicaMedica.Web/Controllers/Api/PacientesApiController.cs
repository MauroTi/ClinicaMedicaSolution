﻿using ClinicaMedica.Web.Models;
using ClinicaMedica.Web.Services;
using Microsoft.AspNetCore.Mvc;

namespace ClinicaMedica.Web.Controllers.Api
{
    [ApiController]
    [Route("api/[controller]")]
    public class PacientesApiController : ControllerBase
    {
        private readonly IPacienteService _pacienteService;

        public PacientesApiController(IPacienteService pacienteService)
        {
            _pacienteService = pacienteService;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var pacientes = await _pacienteService.ObterTodosAsync();
            return Ok(pacientes);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var paciente = await _pacienteService.ObterDtoPorIdAsync(id);
            if (paciente == null) return NotFound();

            return Ok(paciente);
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] Paciente model)
        {
            var resultado = await _pacienteService.CriarAsync(model);

            if (!resultado.Sucesso)
                return BadRequest(new { resultado.Mensagem });

            return CreatedAtAction(nameof(Get), new { id = resultado.Id }, model);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int id, [FromBody] Paciente model)
        {
            if (id != model.Id)
                return BadRequest(new { Mensagem = "ID da rota difere do ID do corpo." });

            var resultado = await _pacienteService.AtualizarAsync(model);

            if (!resultado.Sucesso)
                return BadRequest(new { resultado.Mensagem });

            return Ok(new { resultado.Mensagem });
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var resultado = await _pacienteService.ExcluirAsync(id);

            if (!resultado.Sucesso)
                return BadRequest(new { resultado.Mensagem });

            return Ok(new { resultado.Mensagem });
        }
    }
}