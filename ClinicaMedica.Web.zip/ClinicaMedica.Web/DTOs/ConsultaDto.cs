namespace ClinicaMedica.Web.DTOs
{
    public class ConsultaDto
    {
        public int Id { get; set; }
        public int PacienteId { get; set; }
        public int MedicoId { get; set; }
        public DateTime DataConsulta { get; set; }
        public string Observacoes { get; set; } = string.Empty;
        public string PacienteNome { get; set; } = string.Empty;
        public string MedicoNome { get; set; } = string.Empty;
    }
}