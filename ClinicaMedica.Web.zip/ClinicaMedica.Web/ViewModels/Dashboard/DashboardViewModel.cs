﻿namespace ClinicaMedica.Web.ViewModels.Dashboard
{
    public class DashboardViewModel
    {
        public int TotalPacientes { get; set; }
        public int TotalMedicos { get; set; }
        public int TotalConsultas { get; set; }
        public int ConsultasAgendadas { get; set; }
    }
}