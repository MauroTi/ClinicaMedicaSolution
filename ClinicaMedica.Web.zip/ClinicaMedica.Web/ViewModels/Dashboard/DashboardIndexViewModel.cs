﻿using ClinicaMedica.Web.DTOs;

namespace ClinicaMedica.Web.ViewModels.Dashboard
{
    public class DashboardIndexViewModel
    {
        public DashboardResumoDto Resumo { get; set; } = new();
    }
}