﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace ClinicaMedica.Web.ViewModels.Consultas
{
    public class ConsultaFormViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Selecione o paciente.")]
        [Display(Name = "Paciente")]
        public int PacienteId { get; set; }

        [Required(ErrorMessage = "Selecione o médico.")]
        [Display(Name = "Médico")]
        public int MedicoId { get; set; }

        [Required(ErrorMessage = "Informe a data da consulta.")]
        [Display(Name = "Data da Consulta")]
        [DataType(DataType.DateTime)]
        public DateTime DataConsulta { get; set; } = DateTime.Now;

        [Display(Name = "Observações")]
        [StringLength(500)]
        public string Observacoes { get; set; } = string.Empty;

        public IEnumerable<SelectListItem> Pacientes { get; set; } = Enumerable.Empty<SelectListItem>();
        public IEnumerable<SelectListItem> Medicos { get; set; } = Enumerable.Empty<SelectListItem>();
    }
}