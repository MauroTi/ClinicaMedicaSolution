﻿namespace ClinicaMedica.Web.ViewModels.Consultas
{
    public class ConsultaIndexViewModel
    {
        public IEnumerable<ConsultaListItemViewModel> Consultas { get; set; } = Enumerable.Empty<ConsultaListItemViewModel>();
    }
}