﻿using ClinicaMedica.Web.Data;
using ClinicaMedica.Web.Daos.Interfaces;
using ClinicaMedica.Web.Models;
using Dapper;

namespace ClinicaMedica.Web.Daos
{
    public class ConsultaDao : IConsultaDao
    {
        private readonly DbConnectionFactory _dbConnectionFactory;

        public ConsultaDao(DbConnectionFactory dbConnectionFactory)
        {
            _dbConnectionFactory = dbConnectionFactory;
        }

        public IEnumerable<Consulta> ObterTodos()
        {
            using var connection = _dbConnectionFactory.CreateConnection();

            const string sql = @"
                SELECT 
                    Id,
                    MedicoId,
                    PacienteId,
                    DataHoraConsulta,
                    Valor,
                    Status,
                    Observacoes,
                    DataCadastro
                FROM consultas";

            return connection.Query<Consulta>(sql);
        }

        public Consulta? ObterPorId(int id)
        {
            using var connection = _dbConnectionFactory.CreateConnection();

            const string sql = @"
                SELECT 
                    Id,
                    MedicoId,
                    PacienteId,
                    DataHoraConsulta,
                    Valor,
                    Status,
                    Observacoes,
                    DataCadastro
                FROM consultas
                WHERE Id = @Id";

            return connection.QueryFirstOrDefault<Consulta>(sql, new { Id = id });
        }
    }
}