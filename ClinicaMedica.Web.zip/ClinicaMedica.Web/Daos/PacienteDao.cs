﻿using ClinicaMedica.Web.Data;
using ClinicaMedica.Web.Daos.Interfaces;
using ClinicaMedica.Web.Models;
using Dapper;

namespace ClinicaMedica.Web.Daos
{
    public class PacienteDao : IPacienteDao
    {
        private readonly DbConnectionFactory _dbConnectionFactory;

        public PacienteDao(DbConnectionFactory dbConnectionFactory)
        {
            _dbConnectionFactory = dbConnectionFactory;
        }

        public IEnumerable<Paciente> ObterTodos()
        {
            using var connection = _dbConnectionFactory.CreateConnection();

            const string sql = @"
                SELECT 
                    Id,
                    Nome,
                    Cpf,
                    Telefone,
                    Email,
                    DataNascimento,
                    Ativo,
                    DataCadastro
                FROM pacientes";

            return connection.Query<Paciente>(sql);
        }

        public Paciente? ObterPorId(int id)
        {
            using var connection = _dbConnectionFactory.CreateConnection();

            const string sql = @"
                SELECT 
                    Id,
                    Nome,
                    Cpf,
                    Telefone,
                    Email,
                    DataNascimento,
                    Ativo,
                    DataCadastro
                FROM pacientes
                WHERE Id = @Id";

            return connection.QueryFirstOrDefault<Paciente>(sql, new { Id = id });
        }
    }
}