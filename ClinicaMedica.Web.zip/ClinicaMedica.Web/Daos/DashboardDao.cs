﻿using ClinicaMedica.Web.Daos.Interfaces;
using ClinicaMedica.Web.Data;
using ClinicaMedica.Web.ViewModels.Dashboard;
using Dapper;

namespace ClinicaMedica.Web.Daos
{
    public class DashboardDao : IDashboardDao
    {
        private readonly DbConnectionFactory _dbConnectionFactory;

        public DashboardDao(DbConnectionFactory dbConnectionFactory)
        {
            _dbConnectionFactory = dbConnectionFactory;
        }

        public DashboardViewModel ObterDadosDashboard()
        {
            using var connection = _dbConnectionFactory.CreateConnection();

            var viewModel = new DashboardViewModel
            {
                TotalPacientes = connection.ExecuteScalar<int>("SELECT COUNT(*) FROM pacientes"),
                TotalMedicos = connection.ExecuteScalar<int>("SELECT COUNT(*) FROM medicos"),
                TotalConsultas = connection.ExecuteScalar<int>("SELECT COUNT(*) FROM consultas"),
                ConsultasAgendadas = connection.ExecuteScalar<int>("SELECT COUNT(*) FROM consultas WHERE Status = 'Agendada'")
            };

            return viewModel;
        }
    }
}