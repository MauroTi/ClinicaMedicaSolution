﻿using ClinicaMedica.Web.Models;

namespace ClinicaMedica.Web.Daos.Interfaces
{
    public interface IPacienteDao
    {
        IEnumerable<Paciente> ObterTodos();
        Paciente? ObterPorId(int id);
    }
}