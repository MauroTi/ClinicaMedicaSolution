﻿using ClinicaMedica.Web.Models;

namespace ClinicaMedica.Web.Daos.Interfaces
{
    public interface IConsultaDao
    {
        IEnumerable<Consulta> ObterTodos();
        Consulta? ObterPorId(int id);
    }
}