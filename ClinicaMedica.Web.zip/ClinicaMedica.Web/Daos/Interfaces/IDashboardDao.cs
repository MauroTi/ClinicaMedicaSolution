﻿using ClinicaMedica.Web.ViewModels.Dashboard;

namespace ClinicaMedica.Web.Daos.Interfaces
{
    public interface IDashboardDao
    {
        DashboardViewModel ObterDadosDashboard();
    }
}